var app = angular.module('notesApp', []);
