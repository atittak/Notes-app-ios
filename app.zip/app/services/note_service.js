app.service('NoteService', function () {

  this.NOTE_AUTO_SAVE_TIME = 1000;

  this.getRandomId = function () {
    return parseInt(Math.random()*10000);
  }

  this.computeVisibleNotes = function (notes, folderId) {
    visibleNotes = [];
    selectedNote = {};
    for (var index in notes) {
      if (notes[index].folder == folderId) {
        visibleNotes.push(notes[index]);
      }
    }
    visibleNotes.sort((a, b) => (new Date(a.updatedAt) > new Date(b.updatedAt)) ? -1 : 1);
    return visibleNotes;
  }

});
