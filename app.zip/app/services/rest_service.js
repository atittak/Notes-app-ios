app.service('RestAPIService', function ($http) {

  this.API_BASE_DOMAIN = "https://broken-thunder-7744.getsandbox.com/";

  this.getFolders = function (callback) {
    $http.get(this.API_BASE_DOMAIN + "folders").then(function (response) {
      var folders = response.data;
      folders.sort((a, b) => (a.name > b.name) ? 1 : -1)
      callback && callback(folders);
    });
  }

  this.getNotes = function (callback) {
    $http.get(this.API_BASE_DOMAIN + "notes").then(function (response) {
      var responseData = response.data;
      var notes = {};
      for (var index=0; index < responseData.length; index++) {
        notes[responseData[index].id] = responseData[index];
      }
      callback && callback(notes);
    });
  }

  this.writeFolder = function (folder, callback) {
    $http.post(this.API_BASE_DOMAIN + "folders", newFolder).
    then(function(response) {
      console.log("Folder created!");
      callback && callback(response.data);
    });
  }

  this.writeNote = function (note, callback) {
    $http.post(this.API_BASE_DOMAIN + "notes", note).
    then(function (response) {
      console.log("Note created!");
      callback && callback(response.data);
    });
  }

  this.deleteFolder = function (folderId, callback) {
    $http.delete(API_BASE_DOMAIN + "folders/" + folderId).
    then(function (response) {
      console.log("Folder deleted");
      callback && callback(response.data);
    })
  }

  this.deleteNote = function (noteId, callback) {
    $http.delete(API_BASE_DOMAIN + "notes/" + noteId).
    then(function (response) {
      console.log("Note deleted");
      callback && callback(response.data);
    })
  }
});
