$("document").ready(function () {
  window.panelOpen = true;
  $("#slider-trigger").click(function () {
    if (window.panelOpen) {
      $("#rightPanel").removeClass("m6");
      $("#rightPanel").addClass("m8");
      $("#leftPanel").hide( "slide", { direction: "left", duration: 200 } );
    } else {
      $("#rightPanel").removeClass("m8");
      $("#rightPanel").addClass("m6");
      $("#leftPanel").show( "slide", { direction: "left", duration: 200 } );
    }
    window.panelOpen = !window.panelOpen;
  });
});
