app.controller("NotesController", function ($scope, $http) {

  // scope variable here
  var NOTE_AUTO_SAVE_TIME = 1000; // in milli-seconds
  var API_BASE_DOMAIN = "https://broken-thunder-7744.getsandbox.com/";

  var lastTimeoutDetails = {};

  $scope.folders = [];
  $scope.searchText = "";

  $scope.selectedFolder = -1;
  $scope.selectedNote = {};
  $scope.visibleNotes = [];
  $scope.NoteIsLastClicked = true; // to identify if we need to delete note or folder

  $scope.notes = {};

  // scope functions

  function getRandomId() {
    return parseInt(Math.random()*10000);
  }

  function syncNotes(notePayload) {
    note = JSON.parse(notePayload);
    if (!note.text) {
      return;
    }
    $http.post(API_BASE_DOMAIN + "notes", note).
    then(function(response) {
      console.log("Note created!")
    });
  }

  function computeVisibleNotes() {
    $scope.visibleNotes = [];
    $scope.selectedNote = {};
    for (index in $scope.notes) {
      if ($scope.notes[index].folder == $scope.selectedFolder) {
        $scope.visibleNotes.push($scope.notes[index]);
      }
    }
    $scope.visibleNotes.sort((a, b) => (new Date(a.updatedAt) > new Date(b.updatedAt)) ? -1 : 1)
  }

  $scope.createFolder = function () {
    var name = prompt("Enter folder name");
    var newFolder = {id: getRandomId(), name: name};
    $scope.folders.push(newFolder);
    $http.post(API_BASE_DOMAIN + "folders", newFolder).
    then(function(response) {
      console.log("Folder created!")
    });
  }

  $scope.createNote = function () {
    var newNote = {folder: $scope.selectedFolder, id: getRandomId(), title: "Enter note", text: ""};
    $scope.notes[newNote.id] = newNote;
    $scope.selectedNote = newNote;
    computeVisibleNotes();
  }

  $scope.selectFolder = function (id) {
    $scope.selectedFolder = id;
    $scope.NoteIsLastClicked = false;
    computeVisibleNotes();
  }

  $scope.selectNote = function (id) {
    $scope.selectedNote = $scope.notes[id];
    $scope.NoteIsLastClicked = true;
  }

  $scope.filterNotes = function () {
    computeVisibleNotes();
    if (!$scope.searchText) {
      return;
    }
    var matchingNotes = [];
    for (index=0; index<$scope.visibleNotes.length; index++) {
      if ($scope.visibleNotes[index].text.toLowerCase().indexOf($scope.searchText.toLowerCase()) > -1) {
        matchingNotes.push($scope.visibleNotes[index]);
      }
    }
    $scope.visibleNotes = matchingNotes;

  }

  $scope.delete = function () {
    if ($scope.NoteIsLastClicked) {
      // delete current note
      var deleteId = $scope.selectedNote.id;
      $scope.selectedNote = {};
      if (deleteId) {
          delete $scope.notes[deleteId];
          $http.delete(API_BASE_DOMAIN + "notes/" + deleteId);
      }
    } else {
      var oldFolderList = JSON.parse(JSON.stringify($scope.folders));
      var newFolderList = [];
      for (index=0; index<oldFolderList.length; index++) {
        if (oldFolderList[index].id != $scope.selectedFolder) {
          newFolderList.push(oldFolderList[index])
        }
      }
      $http.delete(API_BASE_DOMAIN + "folders/" + $scope.selectedFolder);
      $scope.selectedFolder = -1
      $scope.folders = newFolderList;
    }
    computeVisibleNotes();
  }

  // Watcher to observe changes in notes
  $scope.$watch('notes', function() {
      if (lastTimeoutDetails && lastTimeoutDetails.noteId == $scope.selectedNote.id) {
        clearTimeout(lastTimeoutDetails.timeoutId);
      }
      if ($scope.selectedNote && $scope.selectedNote.text) {
        var noteDetails = $scope.selectedNote.text.split("\n")
          $scope.selectedNote.title = noteDetails[0];
          if (noteDetails.length >= 1 ){
            $scope.selectedNote.preview = noteDetails[1];
          };
      }
      $scope.selectedNote.updatedAt = (new Date()).toISOString();

      timeoutId = setTimeout(function () {
        $scope.userMessage = "Saving.."
        syncNotes(JSON.stringify($scope.selectedNote));
      }, NOTE_AUTO_SAVE_TIME);
      lastTimeoutDetails = {
        timeoutId: timeoutId,
        noteId: $scope.selectedNote.id
      }
  }, true);

  $http.get(API_BASE_DOMAIN + "folders").then(function (response) {
    var folders = response.data;
    folders.sort((a, b) => (a.name > b.name) ? 1 : -1)
    $scope.folders = folders;
  });

  $http.get(API_BASE_DOMAIN + "notes").then(function (response) {
    var notes = response.data;
    for (var index=0; index < notes.length; index++) {
      $scope.notes[notes[index].id] = notes[index];
    }
  });

});
