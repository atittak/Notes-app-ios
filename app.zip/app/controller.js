app.controller("NotesController", ['$scope', 'RestAPIService', 'NoteService', function ($scope, RestAPIService, NoteService) {
  var lastTimeoutDetails = {};

  $scope.folders = [];
  $scope.searchText = "";

  $scope.selectedFolder = -1;
  $scope.selectedNote = {};
  $scope.visibleNotes = [];
  $scope.NoteIsLastClicked = true; // to identify if we need to delete note or folder

  $scope.notes = {};

  // scope functions

  function syncNotes(notePayload) {
    note = JSON.parse(notePayload);
    if (!note.text) {
      return;
    }
    RestAPIService.writeNote(note);
  }

  $scope.createFolder = function () {
    var name = prompt("Enter folder name");
    var newFolder = {id: NoteService.getRandomId(), name: name};
    $scope.folders.push(newFolder);
    RestAPIService.writeFolder(newFolder);
  }

  $scope.createNote = function () {
    var newNote = {folder: $scope.selectedFolder, id: NoteService.getRandomId(), title: "Enter note", text: ""};
    $scope.notes[newNote.id] = newNote;
    $scope.selectedNote = newNote;
    $scope.visibleNotes = NoteService.computeVisibleNotes($scope.notes, $scope.selectedFolder);
  }

  $scope.selectFolder = function (id) {
    $scope.selectedFolder = id;
    $scope.NoteIsLastClicked = false;
    $scope.visibleNotes = NoteService.computeVisibleNotes($scope.notes, $scope.selectedFolder);
  }

  $scope.selectNote = function (id) {
    $scope.selectedNote = $scope.notes[id];
    $scope.NoteIsLastClicked = true;
  }

  $scope.filterNotes = function () {
    $scope.visibleNotes = NoteService.computeVisibleNotes($scope.notes, $scope.selectedFolder);
    if (!$scope.searchText) {
      return;
    }
    var matchingNotes = [];
    for (index=0; index<$scope.visibleNotes.length; index++) {
      if ($scope.visibleNotes[index].text.toLowerCase().indexOf($scope.searchText.toLowerCase()) > -1) {
        matchingNotes.push($scope.visibleNotes[index]);
      }
    }
    $scope.visibleNotes = matchingNotes;

  }

  $scope.delete = function () {
    if ($scope.NoteIsLastClicked) {
      // delete current note
      var deleteId = $scope.selectedNote.id;
      $scope.selectedNote = {};
      if (deleteId) {
          delete $scope.notes[deleteId];
          RestAPIService.deleteNote(deleteId);
      }
    } else {
      var oldFolderList = JSON.parse(JSON.stringify($scope.folders));
      var newFolderList = [];
      for (index=0; index<oldFolderList.length; index++) {
        if (oldFolderList[index].id != $scope.selectedFolder) {
          newFolderList.push(oldFolderList[index])
        }
      }
      RestAPIService.deleteNote($scope.selectedFolder);
      $scope.selectedFolder = -1
      $scope.folders = newFolderList;
    }
    $scope.visibleNotes = NoteService.computeVisibleNotes($scope.notes, $scope.selectedFolder);
  }

  // Watcher to observe changes in notes
  $scope.$watch('notes', function() {
      if (lastTimeoutDetails && lastTimeoutDetails.noteId == $scope.selectedNote.id) {
        clearTimeout(lastTimeoutDetails.timeoutId);
      }
      if ($scope.selectedNote && $scope.selectedNote.text) {
        var noteDetails = $scope.selectedNote.text.split("\n")
          $scope.selectedNote.title = noteDetails[0];
          if (noteDetails.length >= 1 ){
            $scope.selectedNote.preview = noteDetails[1];
          };
      }
      $scope.selectedNote.updatedAt = (new Date()).toISOString();

      timeoutId = setTimeout(function () {
        $scope.userMessage = "Saving.."
        syncNotes(JSON.stringify($scope.selectedNote));
      }, NoteService.NOTE_AUTO_SAVE_TIME);
      lastTimeoutDetails = {
        timeoutId: timeoutId,
        noteId: $scope.selectedNote.id
      }
  }, true);
  

  RestAPIService.getFolders(function (folders) {
    $scope.folders = folders;
  });

  RestAPIService.getNotes(function (notes) {
    $scope.notes = notes;
  });

}]);
